import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './login/Login';
import Signup from './sign_up/sign_up'; // Adjust the import path as needed
import Form from './OrderForm/LunchMenuTable';
import Home from "../src/Userpage/Routes/Home";
import Orderhistory from './Userpage/Routes/Orderhistory';
import Calendar from './Userpage/Components/Calendar';
import Reports from './AdminFolder/Routes/Reports';
import AdminHome from './AdminFolder/Routes/Home';
import Usertable from './AdminFolder/Routes/Usertable';
import Table from './AdminFolder/components/Table';
import Addmenu from './AdminFolder/Routes/Addmenu';


const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/lunch" element={<Form />} />
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/home" element={<Home />} />
        <Route path="/orderhistory" element={<Orderhistory />} />
        <Route path="/calendar" element={<Calendar />} />
        <Route path="/adminhome" element={<AdminHome />} />
        <Route path="/usertable" element={<Usertable />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/table" element={<Table />} />
        <Route path="/addmenu" element={<Addmenu />} />
      </Routes>
    </Router>
  );
};

export default App;