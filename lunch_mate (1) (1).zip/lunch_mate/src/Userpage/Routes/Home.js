import React, { useState } from "react";
import Calendar from "../Components/Calendar";
import Details from "../Components/Details";
// import '../components/Calendar.css';
import "../Components/Calendar.css";
import Navbar from "../Components/Navbar";

function Home() {
  const [showDetails, setShowDetails] = useState(false);
  const [data, setData] = useState(null);

  const showDetailsHandle = (dayStr) => {
    setData(dayStr);
    setShowDetails(true);
  };
  return (
    <div className="Home">
        <Navbar></Navbar>
      <center>
        <h1>Home</h1>
      </center>
      <Calendar showDetailsHandle={showDetailsHandle} />
      <br />
      {showDetails && <Details data={data} />}
    </div>
  );
}
export default Home;
