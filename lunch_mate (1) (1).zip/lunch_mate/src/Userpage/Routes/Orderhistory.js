import Table from "../Components/Table";
import "../Components/Table.css";
import Navbar from "../Components/Navbar";
 
function  Orderhistory(){
    return(
        <div className="Orderhistory">
            <Navbar></Navbar>
            <center>
            <h1>Orderhistory</h1>
            </center>
            <Table></Table>
        </div>
    );
}
 
export default Orderhistory;