import React from "react";
import * as AiIcons from "react-icons/ai";
import * as IoIcons from "react-icons/io";

export const Sidebardata = [
  {
    title: "Home",
    path: "/home",
    icon: <AiIcons.AiFillHome />,
    cName: "nav-text",
  },

  {
  title:"OrderForm",
  path:"/lunch",
  icon:<AiIcons.AiFillApi/>,
  cName:"nav-text",
  },
  {
    title: "Orderhistory",
    path: "/Orderhistory",
    icon: <IoIcons.IoMdCalendar />,
    cName: "nav-text",
  },
];