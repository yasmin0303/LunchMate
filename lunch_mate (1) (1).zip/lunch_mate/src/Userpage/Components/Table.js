import React, { useState } from 'react';
import"./Table.css";
const data = [
  { date: "08/18/2024", ordernumber: 9, orderquantity: 6 },
  { date: "08/19/2024", ordernumber: 5, orderquantity: 4 },
  { date: "08/20/2024", ordernumber: 17, orderquantity: 9 },
  { date: "08/21/2024", ordernumber: 4, orderquantity: 2 },
  { date: "08/22/2024", ordernumber: 7, orderquantity: 8 },
  { date: "08/23/2024", ordernumber: 13, orderquantity: 7 },
  { date: "08/24/2024", ordernumber: 9, orderquantity: 1 },
  { date: "08/25/2024", ordernumber: 8, orderquantity: 4 },
  { date: "08/26/2024", ordernumber: 12, orderquantity: 9 },
];

function Table() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [filteredData, setFilteredData] = useState(data);

  const parseDate = (dateString) => {
    const [month, day, year] = dateString.split('/');
    return new Date(`${year}-${month}-${day}`);
  };

  const filterData = () => {
    const start = startDate ? parseDate(startDate) : null;
    const end = endDate ? parseDate(endDate) : null;
    
    const filtered = data.filter(item => {
      const itemDate = parseDate(item.date);
      return (!start || itemDate >= start) && (!end || itemDate <= end);
    });
    
    setFilteredData(filtered);
  };

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };

  return (
    <div className="Table">
      <div className="filter-controls">
        <label>
          From: 
          <input 
            type="date" 
            className="filter-input" 
            value={startDate} 
            onChange={handleStartDateChange} 
          />
        </label>
        <label>
          To: 
          <input 
            type="date" 
            className="filter-input" 
            value={endDate} 
            onChange={handleEndDateChange} 
          />
        </label>
        <button 
          onClick={filterData} 
          className="submit-button"
        >
          Submit
        </button>
      </div>
      <table>
        <thead>
          <tr>
            <th>DATE</th>
            <th>ORDER NUMBER</th>
            <th>QUANTITY</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length > 0 ? (
            filteredData.map((val, key) => (
              <tr key={key}>
                <td>{val.date}</td>
                <td>{val.ordernumber}</td>
                <td>{val.orderquantity}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3">No data available for the selected date range.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Table;
