// src/components/Signup.js
import React, { useState } from 'react';
import { Link } from "react-router-dom";
import '../sign_up/signup.css'; // Import regular CSS
import Navbar from '../Navbar/Nav';

const Signup = () => {
  const [passwordVisible, setPasswordVisible] = useState(false);

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  return (
    
    <div>
      
    <div className="sign">
    {/* <Navbar/> */}
      <form action="" className="container">
        <h1 className="sign__title">LunchMate</h1>
        <center><h4>Signup</h4></center>
        <div className="sign__content">
          <div className="sign__box">
            <i className={`ri-user-3-line sign__icon`}></i>

            <div className="sign__boxInput">
              <input
                type="email"
                required
                className="sign__input"
                id="sign-email"
                placeholder=" "
              />
              <label htmlFor="sign-email" className="sign__label">Email</label>
            </div>
          </div>

          <div className="sign__box">
            <i className={`ri-lock-2-line sign__icon`}></i>

            <div className="sign__boxInput">
              <input
                type={passwordVisible ? "text" : "password"}
                required
                className="sign__input"
                id="sign-pass"
                placeholder=" "
              />
              <label htmlFor="sign-pass" className="sign__label">Password</label>
              <i
                className={`ri-eye-${passwordVisible ? 'line' : 'off-line'} sign__eye`}
                id="sign-eye"
                onClick={togglePasswordVisibility}
              ></i>
            </div>
          </div>

          <div className="sign__box">
            <i className={`ri-lock-2-line sign__icon`}></i>

            <div className="sign__boxInput">
              <input
                type={passwordVisible ? "text" : "password"}
                required
                className="sign__input"
                id="sign-pass-confirm"
                placeholder=" "
              />
              <label htmlFor="sign-pass-confirm" className="sign__label">Confirm Password</label>
              <i
                className={`ri-eye-${passwordVisible ? 'line' : 'off-line'} sign__eye`}
                id="sign-eye-confirm"
                onClick={togglePasswordVisibility}
              ></i>
            </div>
          </div>
        </div>
        <div className="sign__check">
          <div className="sign__checkGroup">
            <input type="checkbox" className="sign__checkInput" id="sign-check" />
            <label htmlFor="sign-check" className="sign__checkLabel">Day shift</label>
          </div>
          <div className="sign__checkGroup">
            <input type="checkbox" className="sign__checkInput" id="sign-check" />
            <label htmlFor="sign-check" className="sign__checkLabel">Night shift</label>
          </div>
        </div>

        {/* <div className="sign__check">
          <a href="#" className="sign__forgot">Forgot Password?</a>
        </div> */}

        <button type="submit" className="sign__button">Submit</button>
        <div className="sign__title">
          <Link to="/" className="dropdown-item">Back to login</Link>
        </div>
      </form>
    </div>
    </div>
  );
};

export default Signup;