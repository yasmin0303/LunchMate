import React from 'react';
import styles from '../Navbar/Navbar.module.css' // Import the CSS Module
import logo from '../logo.png';
 
const Navbar = () => {
  return (
    <nav className={styles.navbar}>
      <div className={styles.navbarContent}>
        <img className={styles.navbarLogo} src={logo} alt="logo" />
        <ul className={styles.navbarLinks}>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
    </nav>
  );
};
 
export default Navbar;
 