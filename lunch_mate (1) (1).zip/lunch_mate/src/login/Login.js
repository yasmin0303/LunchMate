import React, { useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import Navbar from '../Navbar/Nav';
import '../login/Login.css'; // Import regular CSS

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [error, setError] = useState('');

  const navigate = useNavigate();

  const correctUsername = 'yasmin@gmail.com';
  const correctPassword = 'password123';

  const correctAdminUsername = 'admin@gmail.com';
  const correctAdminPassword = 'password123';

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email === correctUsername && password === correctPassword) {
      navigate('/home');
    } else if(email === correctAdminUsername && password === correctAdminPassword) {
      navigate('/adminhome');
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div className="login">
      {/* <Navbar/> */}
      <form onSubmit={handleSubmit} className="container">
        <h1 className="login__title">LunchMate</h1>
        <center><h4>Login</h4></center>
        <div className="login__content">
          <div className="login__box">
            <i className={`ri-user-3-line login__icon`}></i>

            <div className="login__box-input">
              <input 
                type="email" 
                required 
                className="login__input" 
                id="login-email" 
                placeholder=" " 
                // value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <label htmlFor="login-email" className="login__label">Email</label>
            </div>
          </div>

          <div className="login__box">
            <i className={`ri-lock-2-line login__icon`}></i>

            <div className="login__box-input">
              <input 
                type={passwordVisible ? "text" : "password"} 
                required 
                className="login__input" 
                id="login-pass" 
                placeholder=" " 
                
                onChange={(e) => setPassword(e.target.value)}
              />
              <label htmlFor="login-pass" className="login__label">Password</label>
              <i 
                className={`ri-eye-${passwordVisible ? 'line' : 'off-line'} login__eye`} 
                id="login-eye" 
                onClick={togglePasswordVisibility}
              ></i>
            </div>
          </div>
        </div>

        {error && <p className="login__error">{error}</p>}


        <button type="submit" className="login__button">Login</button>
        <p className="login__register">
          Don't have an account? 
          <Link to="/signup" className="login__registerLink">Register</Link>
        </p>
      </form>
    </div>
  );
};

export default Login;