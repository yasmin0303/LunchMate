import React, { useState } from 'react';
import styles from '../OrderForm/Form.module.css'; // Import the CSS Module
import Nav from '../Navbar/Nav'; // Import the Navbar component
import LunchMenuTable from './LunchMenuTable';

const predefinedDishes = [
  'Pizza',
  'Burger',
  'Pasta',
  'Salad',
  'Sushi'
];

const Form = () => {
  const [email, setEmail] = useState('');
  const [days, setDays] = useState({
    monday: { date: '', dish: predefinedDishes[0], quantity: 0 },
    tuesday: { date: '', dish: predefinedDishes[0], quantity: 0 },
    wednesday: { date: '', dish: predefinedDishes[0], quantity: 0 },
    thursday: { date: '', dish: predefinedDishes[0], quantity: 0 },
    friday: { date: '', dish: predefinedDishes[0], quantity: 0 }
  });

  const handleEmailChange = (e) => setEmail(e.target.value);
  
  const handleDateChange = (e, day) => {
    setDays({
      ...days,
      [day]: {
        ...days[day],
        date: e.target.value
      }
    });
  };

  const handleDishChange = (e, day) => {
    setDays({
      ...days,
      [day]: {
        ...days[day],
        dish: e.target.value
      }
    });
  };

  const handleQuantityChange = (e, day) => {
    setDays({
      ...days,
      [day]: {
        ...days[day],
        quantity: e.target.value
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Submitted');
    console.log('Email:', email);
    console.log('Days and Dishes:', days);
    
    // Here you can handle form submission, e.g., send data to an API
  };

  return (
    <div>
      <Nav />
      <main style={{ paddingTop: '60px' }}> {/* Adjust padding to account for the navbar */}
  
          <LunchMenuTable/>

        <form className={styles.orderform} onSubmit={handleSubmit}>
          <div>
            <label>
              Email:
              <input
                className={styles.formEmail}
                type="email"
                value={email}
                onChange={handleEmailChange}
                required
              />
            </label>
          </div>
          <div>
            {Object.keys(days).map(day => (
              <div key={day} className={styles.dayContainer}>
                <label>
                  {day.charAt(0).toUpperCase() + day.slice(1)}
                </label>
                <input
                  type="date"
                  value={days[day].date}
                  onChange={(e) => handleDateChange(e, day)}
                />
                {/* <select
                  value={days[day].dish}
                  onChange={(e) => handleDishChange(e, day)}
                >
                  {predefinedDishes.map(dish => (
                    <option key={dish} value={dish}>
                      {dish}
                    </option>
                  ))}
                </select> */}
                <input
                  type="number"
                  value={days[day].quantity}
                  onChange={(e) => handleQuantityChange(e, day)}
                  min="1"
                />
              </div>
            ))}
          </div>
          <button type="submit">Submit</button>
        </form>
      </main>
    </div>
  );
};

export default Form;
