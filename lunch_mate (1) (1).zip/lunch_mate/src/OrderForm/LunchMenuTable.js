import React, { useState } from 'react';
import styles from '../OrderForm/LunchMenuTable.css'; // Import the CSS Module
import Navbar from '../Userpage/Components/Navbar';

const LunchMenuTable = () => {
  const dayshift = [
    { date: '2024-08-19', day: 'Monday', lunch: 'Grilled Chicken', time: '12:00 PM - 1:00 PM' },
    { date: '2024-08-20', day: 'Tuesday', lunch: 'Pasta', time: '12:00 PM - 1:00 PM' },
    { date: '2024-08-21', day: 'Wednesday', lunch: 'Salad', time: '12:00 PM - 1:00 PM' },
    { date: '2024-08-22', day: 'Thursday', lunch: 'Sandwich', time: '12:00 PM - 1:00 PM' },
    { date: '2024-08-23', day: 'Friday', lunch: 'Pizza', time: '12:00 PM - 1:00 PM' },
  ];
  const NightShift = [
    { date: '2024-08-19', day: 'Monday', lunch: 'Grilled Chicken', time: '11:00 PM - 12:00 AM' },
    { date: '2024-08-20', day: 'Tuesday', lunch: 'Pasta', time: '11:00 PM - 12:00 AM' },
    { date: '2024-08-21', day: 'Wednesday', lunch: 'Salad', time: '11:00 PM - 12:00 AM' },
    { date: '2024-08-22', day: 'Thursday', lunch: 'Sandwich', time: '11:00 PM - 12:00 AM' },
    { date: '2024-08-23', day: 'Friday', lunch: 'Pizza', time: '11:00 PM - 12:00 AM' },
  ];
  const [selectedShift, setSelectedShift] = useState(dayshift);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [submittedData, setSubmittedData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSelectChange = (event) => {
    const value = event.target.value;
    setSelectedShift(value === "NightShift" ? NightShift : dayshift);
    setSelectedRows([]);
    setSelectAll(false);
  };

  const handleRowCheckboxChange = (index) => {
    const newSelectedRows = [...selectedRows];
    if (newSelectedRows.includes(index)) {
      newSelectedRows.splice(newSelectedRows.indexOf(index), 1);
    } else {
      newSelectedRows.push(index);
    }
    setSelectedRows(newSelectedRows);
  };

  const handleSelectAllChange = () => {
    if (selectAll) {
      setSelectedRows([]);
    } else {
      setSelectedRows(selectedShift.map((_, index) => index));
    }
    setSelectAll(!selectAll);
  };

  const handleSubmit = () => {
    const selectedData = selectedRows.map(index => selectedShift[index]);
    setSubmittedData(selectedData);
    if (selectedData.length > 0) {
      setIsModalOpen(true);
    }
  };

  const handleConfirm = () => {
    console.log(submittedData);
    setIsModalOpen(false);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };
  return (
    <div>
      <div className={styles.Navbar}>
        <Navbar />
      </div>
      <div className={styles.tableContainer}>
        <select id='formdropdown' onChange={handleSelectChange}>
          <option value="day shift">DayShift</option>
          <option value="NightShift">NightShift</option>
        </select>
        <table className={styles.table}>
          <thead>
            <tr>
              <th className={styles.th}>
                <input
                  type="checkbox"
                  checked={selectAll}
                  onChange={handleSelectAllChange}
                />
              </th>
              <th className={styles.th}>Date</th>
              <th className={styles.th}>Day</th>
              <th className={styles.th}>Time</th>
              <th className={styles.th}>Lunch</th>
            </tr>
          </thead>
          <tbody>
            {selectedShift.map((item, index) => (
              <tr key={index} className={styles.tr}>
                <td className={styles.td}>
                  <input
                    type="checkbox"
                    checked={selectedRows.includes(index)}
                    onChange={() => handleRowCheckboxChange(index)}
                  />
                </td>
                <td className={styles.td}>{item.date}</td>
                <td className={styles.td}>{item.day}</td>
                <td className={styles.td}>{item.time}</td>
                <td className={styles.td}>{item.lunch}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <button id='formbtn' onClick={handleSubmit}>Submit</button>
      </div>
      {isModalOpen && (
        <div className={styles.modal}>
          <div className={styles.modalContent}>
            <span className={styles.close} onClick={handleCloseModal}>×</span>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th className={styles.th}>Date</th>
                  <th className={styles.th}>Lunch</th>
                </tr>
              </thead>
              <tbody>
                {submittedData.map((item, index) => (
                  <tr key={index} className={styles.tr}>
                    <td className={styles.td}>{item.date}</td>
                    <td className={styles.td}>{item.lunch}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button id='formbtn'onClick={handleConfirm}>Confirm</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default LunchMenuTable;