import Tableuser from "../components/Tableuser";
import "../components/Table.css"
import Navbar from "../components/Navbar";

function Usertable(){
    return(
        <div className="Usertable">
             
            <center>
            <Navbar/>
            <h1>USERINFO 📖</h1>
            <hr></hr>
            <Tableuser/>
            </center>
            
           
        </div>
    );
}

export default Usertable;