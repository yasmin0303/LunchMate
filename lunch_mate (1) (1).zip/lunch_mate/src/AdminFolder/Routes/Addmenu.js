import React from 'react'
import Menu from '../components/Menu';
import Navbar from '../components/Navbar';

function Addmenu() {
  return (
    <div>
      <Navbar></Navbar>
      <center>
        <h1>ADDMENU</h1>
      </center>
      <hr></hr>
      <Menu />
    </div>
  )
}

export default Addmenu