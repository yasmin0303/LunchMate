import Table from "../components/Table";
import "../components/Table.css";
import Navbar from "../components/Navbar";

function Reports() {
  return (
    <div>
       <hr></hr>
       <Table></Table>   
    </div>
  )
}

export default Reports;