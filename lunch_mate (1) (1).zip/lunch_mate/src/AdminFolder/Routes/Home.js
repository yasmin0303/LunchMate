import React from "react";
import Donutchart from "../components/Donutchart";
import Navbar from "../components/Navbar";

function Home() {
    return (
        <div className="Home">
            <Navbar></Navbar>
            <center>
                <h1>HOME </h1>
            </center>
            <hr></hr>
            <Donutchart />
        </div>
    );
}

export default Home;