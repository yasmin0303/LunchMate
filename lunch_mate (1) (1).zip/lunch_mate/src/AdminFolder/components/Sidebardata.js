import React from "react";
import * as AiIcons from "react-icons/ai";
import * as IoIcons from "react-icons/io";
import * as FaIcons from "react-icons/fa";

export const Sidebardata = [
  {
    title: "Home",
    path: "/adminhome",
    icon: <AiIcons.AiFillHome />,
    cName: "nav-text",
  },
  {
    title: "Reports",
    path: "/reports",
    icon: <IoIcons.IoIosPaper />,
    cName: "nav-text",
  },
  {
    title: "Usertable",
    path: "/usertable",
    icon: <IoIcons.IoMdPeople />,
    cName: "nav-text",
  },
  {
    title: "Addmenu",
    path: "/addmenu",
    icon: <FaIcons.FaBars />,
    cName: "nav-text",
  },
];
