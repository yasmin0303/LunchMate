import React, { useState } from 'react';
import"../components/Table.css";
import Navbar from './Navbar';

const data = [
    { id: 1, date: "12/9/2004", email: "max12@gmail.com", orderquantity: 6 },
    { id: 2, date: "11/9/2004", email: "jay12@GMail.com", orderquantity: 14 },
    { id: 3, date: "19/9/2004", email: "raj10@gmail.com", orderquantity: 9 },
    { id: 4, date: "17/9/2004", email: "thiru2gmail.com", orderquantity: 8 },
    { id: 5, date: "16/9/2004", email: "geetha9@GMail.com", orderquantity: 34 },
    { id: 6, date: "14/9/2004", email: "vena7@gmail.com", orderquantity: 92 },
];
 
function Table() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [filteredData, setFilteredData] = useState(data);
 
  const parseDate = (dateString) => {
    const [month, day, year] = dateString.split('/');
    return new Date(`${year}-${month}-${day}`);
  };
 
  const filterData = () => {
    const start = startDate ? parseDate(startDate) : null;
    const end = endDate ? parseDate(endDate) : null;
   
    const filtered = data.filter(item => {
      const itemDate = parseDate(item.date);
      return (!start || itemDate >= start) && (!end || itemDate <= end);
    });
   
    setFilteredData(filtered);
  };
 
  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
  };
 
  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
  };
 
  return (
    <div>
    <Navbar></Navbar>
    <center> <h1>REPORTS 📖</h1>
    </center>  
    <hr></hr>
    <div className="Table">
      <div className="filter-controls">
        <label>
          From:
          <input
            type="date"
            className="filter-input"
            value={startDate}
            onChange={handleStartDateChange}
          />
        </label>
        <label>
          To:
          <input
            type="date"
            className="filter-input"
            value={endDate}
            onChange={handleEndDateChange}
          />
        </label>
        <button
          onClick={filterData}
          className="submit-button"
        >
          Submit
        </button>
      </div>
      
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>DATE</th>
            <th>EMAIL</th>
            <th>ORDERQUANTITY</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length > 0 ? (
            filteredData.map((val, key) => (
              <tr key={key}>
                <td>{val.id}</td>
                <td>{val.date}</td>
                <td>{val.email}</td>
                <td>{val.orderquantity}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="3">No data available for the selected date range.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
    </div>
  );
}
 
export default Table;