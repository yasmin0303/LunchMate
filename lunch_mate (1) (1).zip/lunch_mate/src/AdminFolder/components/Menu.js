import React, { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Table from 'react-bootstrap/Table';
import '../components/Addmenu.css'; // Ensure this path is correct

const weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
const shifts = ["Morning Shift", "Night Shift"];

function Menu() {
    const [inputs, setInputs] = useState({});
    const [submittedData, setSubmittedData] = useState({});
    const [isFormValid, setIsFormValid] = useState(false);
    const [isConfirmed, setIsConfirmed] = useState(false);

    // Helper function to get the date for a specific weekday
    const getDateForWeekday = (startDate, dayOffset) => {
        const date = new Date(startDate);
        date.setDate(date.getDate() + dayOffset);
        return date.toISOString().split('T')[0]; // Format as YYYY-MM-DD
    };

    useEffect(() => {
        // Set the initial dates based on today’s date
        const today = new Date();
        const startOfWeek = today.getDate() - today.getDay() + 1; // Set start of week to Monday
        const initialInputs = {};

        weekdays.forEach((day, index) => {
            initialInputs[day] = {
                meal: '',
                date: getDateForWeekday(today, startOfWeek + index),
                shift: shifts[0], // Default to "Morning Shift"
            };
        });

        setInputs(initialInputs);
    }, []);

    useEffect(() => {
        // Check if all meal inputs have values
        const allFilled = weekdays.every(day => inputs[day]?.meal && inputs[day]?.shift);
        setIsFormValid(allFilled);
    }, [inputs]);

    const handleMealChange = (day, event) => {
        setInputs(prevInputs => ({
            ...prevInputs,
            [day]: { ...prevInputs[day], meal: event.target.value }
        }));
    };

    const handleDateChange = (day, event) => {
        setInputs(prevInputs => ({
            ...prevInputs,
            [day]: { ...prevInputs[day], date: event.target.value }
        }));
    };

    const handleShiftChange = (day, event) => {
        setInputs(prevInputs => ({
            ...prevInputs,
            [day]: { ...prevInputs[day], shift: event.target.value }
        }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        setSubmittedData(inputs); // Save form data to be displayed
        setIsConfirmed(false); // Reset confirmation status
    };

    const handleConfirm = () => {
        console.log('Confirmed Data:', submittedData);
        setIsConfirmed(true); // Mark data as confirmed
    };

    return (
        <div className="admin-container">
            <center>
            <h2>UPCOMING WEEK MEAL PLAN  🍖</h2>
            </center>
            {/* Form for input */}
            <Form onSubmit={handleSubmit}>
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>WEEKDAY</th>
                            <th>DATE (YYYY-MM-DD)</th>
                            <th>MEAL</th>
                            <th>SHIFT</th>
                        </tr>
                    </thead>
                    <tbody>
                        {weekdays.map(day => (
                            <tr key={day}>
                                <td>{day}</td>
                                <td>
                                    <Form.Control
                                        type="date"
                                        value={inputs[day]?.date || ''}
                                        onChange={(event) => handleDateChange(day, event)}
                                    />
                                </td>
                                <td>
                                    <Form.Control
                                        type="text"
                                        value={inputs[day]?.meal || ''}
                                        onChange={(event) => handleMealChange(day, event)}
                                        placeholder={`Enter meal for ${day}`}
                                    />
                                </td>
                                <td>
                                    <Form.Control
                                        as="select"
                                        value={inputs[day]?.shift || shifts[0]}
                                        onChange={(event) => handleShiftChange(day, event)}
                                    >
                                        {shifts.map(shift => (
                                            <option key={shift} value={shift}>
                                                {shift}
                                            </option>
                                        ))}
                                    </Form.Control>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
                <center>
                <Button type="submit" variant="primary" disabled={!isFormValid}>Submit</Button>
                </center>
            </Form>

            {/* Display table and confirm button */}
            {Object.keys(submittedData).length > 0 && (
                <>
                    <h2 className="mt-4">Submitted Data</h2>
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>WEEKDAY</th>
                                <th>DATE(YYYY-MM-DD)</th>
                                <th>MEAL</th>
                                <th>SHIFT</th>
                            </tr>
                        </thead>
                        <tbody>
                            {weekdays.map(day => (
                                <tr key={day}>
                                    <td>{day}</td>
                                    <td>{submittedData[day]?.date || ''}</td>
                                    <td>{submittedData[day]?.meal || ''}</td>
                                    <td>{submittedData[day]?.shift || ''}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                    {!isConfirmed && (
                        <center>
                        <Button
                            variant="success"
                            onClick={handleConfirm}
                            className="mt-3"
                        >
                            Confirm
                        </Button>
                        </center>
                    )}
                    {isConfirmed && <p className="mt-3">Data has been confirmed and logged to the console.</p>}
                </>
            )}
        </div>
    );
}

export default Menu;