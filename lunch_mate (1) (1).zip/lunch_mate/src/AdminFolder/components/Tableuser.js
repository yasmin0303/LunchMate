import React, { useState } from 'react';
import '../components/Tableuser.css';

const Tableuser = () => {
  // Default data array
  const defaultData = [
    { id: 1, date: '12/09/2024', email: 'max12@gmail.com',  quantity: 6  ,userstatus:"active"},
    { id: 2, date: '11/09/2024', email: 'jay12@GMail.com',  quantity: 14, userstatus:"active"},
    { id: 3, date: '19/09/2024', email: 'raj10@gmail.com',  quantity: 9,userstatus:"active" },
    { id: 4, date: '17/09/2024', email: 'thiru2@gmail.com',  quantity: 8 ,userstatus:"inactive"},
    { id: 5, date: '16/09/2024', email: 'geetha9@GMail.com',  quantity: 34 ,userstatus:"active"},
    { id: 6, date: '14/09/2024', email: 'vena7@gmail.com',  quantity: 92 ,userstatus:"active"},
  ];
 

  const [data, setData] = useState(defaultData);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const handleFilter = () => {
    const filteredData = defaultData.filter(item => {
      const itemDate = new Date(item.date.split('/').reverse().join('-'));
      const startDate = new Date(fromDate);
      const endDate = new Date(toDate);

      return (!fromDate || itemDate >= startDate) && (!toDate || itemDate <= endDate);
    });
    setData(filteredData);
  };

  return (

    
    <div className="table-container">
      <div className="filter-section">
        <label>
          From:
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
          />
        </label>
        <label>
          To:
          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
          />
        </label>
        <button onClick={handleFilter}>Submit</button>
      </div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>DATE</th>
            <th>EMAIL</th>
            <th>QUANTITY</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.date}</td>
              <td>{item.email}</td>
              
              <td>{item.quantity}</td>
              <td>{item.userstatus}</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>

  );
};

export default Tableuser;
