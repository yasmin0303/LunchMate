// App.js
import React, { useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
// import '../Donutchart.css';
import '../components/Donutchart.css'
// Register Chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

function Donutchart() {
  const [orderCounts, setOrderCounts] = useState({
    Monday: 7,
    Tuesday: 16,
    Wednesday: 10,
    Thursday: 40,
    Friday: 12
  });

  // Define maximum orders for the progress bar
  const maxOrders = 15;

  // Function to get color based on the order count
  const getColor = (count) => {
    return count < maxOrders ? '#f44336' : '#4caf50'; // Red if below 15, Green if 15 or above
  };

  return (
    <div className="conti">
      {weekdays.map((day) => {
        const count = orderCounts[day];
        const data = {
          labels: ['Orders'],
          datasets: [
            {
              data: [count, maxOrders - count],
              backgroundColor: [getColor(count), '#d6d6d6'],
              borderWidth: 0,
            },
          ],
        };

        const options = {
          responsive: true,
          plugins: {
            tooltip: {
              callbacks: {
                label: () => `Order Count: ${count}`,
              },
            },
            legend: {
              display: false,
            },
          },
          cutout: '70%', // Makes the chart a donut
        };

        return (
          <div key={day} className="chart-container">
            <h3>{day}</h3>
            <Doughnut data={data} options={options} />
          </div>
        );
      })}
    </div>
  );
}

export default Donutchart;
